// ******************************************************************/
// ECE 3574, Project 1, Alexander LePelch
//
// File name: ui_main_window.cpp
// Description: Implementation file for ui_main)window.cpp
// ******************************************************************/

#include <iostream>

// QT Includes
#include <QTextEdit>
#include <QTextStream>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>
#include <QtWebKit/QWebView>
#include <QDialog>
#include <QFileDialog>
#include <QKeyEvent>
#include <QAction>
#include <QKeySequence>
#include <QFile>
#include <string>
#include <QDebug>

#include "ui_main_window.h"

//*************************************************************//
// MainWindow() constructor
//*************************************************************//
Ui_MainWindow::Ui_MainWindow()
{
	htmlFilename = "toHtml.html";
	arraySize = 0; 
	hasSaved = false;
}

//*************************************************************//
// MainWindow() destructor
//*************************************************************//
Ui_MainWindow::~Ui_MainWindow()
{
	QFile::remove("toHtml.html");
	delete[] array;
}

//*************************************************************//
// Initialize GUI content. Code generated from in QTDesigner
//*************************************************************//
void Ui_MainWindow::setupUi(QMainWindow *MainWindow)
{
	if (MainWindow->objectName().isEmpty())
        MainWindow->setObjectName(QString::fromUtf8("MainWindow"));

    MainWindow->resize(783, 600);
    centralwidget = new QWidget(MainWindow);
    centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
    
    splitter = new QSplitter(centralwidget);
    splitter->setObjectName(QString::fromUtf8("splitter"));
    splitter->setGeometry(QRect(13, 10, 1056, 600));
    splitter->setOrientation(Qt::Horizontal);
    
    textEdit = new QTextEdit(splitter);
    textEdit->setObjectName(QString::fromUtf8("textEdit"));
    splitter->addWidget(textEdit);
    
    webView = new QWebView(splitter);
    webView->setObjectName(QString::fromUtf8("webView"));
    webView->setUrl(QUrl(QString::fromUtf8("about:blank")));
    splitter->addWidget(webView);
    
    MainWindow->setCentralWidget(centralwidget);
    menubar = new QMenuBar(MainWindow);
    menubar->setObjectName(QString::fromUtf8("menubar"));
    menubar->setGeometry(QRect(0, 0, 783, 21));
    
    MainWindow->setMenuBar(menubar);
    statusbar = new QStatusBar(MainWindow);
    statusbar->setObjectName(QString::fromUtf8("statusbar"));
    MainWindow->setStatusBar(statusbar);

    MainWindow->setWindowTitle(QApplication::translate("Qt Markup", "Qt Markup", 0, QApplication::UnicodeUTF8));

    action = new QAction("Action", this);
    QAction *save = new QAction(action);

    action->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_O));
    save->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_S));

    centralwidget->addAction(action);
    centralwidget->addAction(save);

    QMetaObject::connectSlotsByName(MainWindow);
    QObject::connect(textEdit, SIGNAL(textChanged()), this, SLOT(markup()));
    QObject::connect(action, SIGNAL(triggered()), this, SLOT(CTRL_O()));
    QObject::connect(save, SIGNAL(triggered()),  this, SLOT(CTRL_S()));
    QObject::connect(textEdit, SIGNAL(textChanged()), this, SLOT(viewHTML()));
}

//****************************************************//
// Markup() is the heart of the program:
// 1. Read in content from text editor 
// 2. create a list of the .sm file content by line
// 3. dynamically allocate array of size = list size
// 4. Parse the list, markup to HTML
// 5. Save the marked up text to an html file
//****************************************************//
void Ui_MainWindow::markup()
{
	// Set Qstring to content of textEditor
	QString myText = this->textEdit->toPlainText();

	// Copy used for testing
	myTextOpen = this->textEdit->toPlainText();

	// create an array of lines in text editor
	myTextToArray(myText);

	// Parse the text and markup
	parse();

	// Save marked up text to .html file
	saveHtmlFile();
}

//****************************************************//
// Convert QString text to a dynamically 
// allocated  array of text editor lines
//****************************************************//
void Ui_MainWindow::myTextToArray(QString &myText)
{
	list = myText.split("\n");

    array = new QString [list.size()];
    arraySize = list.size();
}

//****************************************************//
// Load html file and display on QWebViewer
//****************************************************//
void Ui_MainWindow::viewHTML()
{
	webView->load(QUrl("toHtml.html"));
}

//****************************************************//
// Control+O Shortcut handler, opens file and reads
// its content into text editor
//****************************************************//
void Ui_MainWindow::CTRL_O()
{
	// Open a file
	QFileDialog *fd = new QFileDialog();
	fd->setFileMode(QFileDialog::ExistingFile);
	
	if(fd->exec())
	{
		filename = fd->selectedFiles().front();

		// Read in the content of file
		QString myText;
		readSmFile(myText);

		// Place text from file into text editor
		textEdit->clear();
		textEdit->insertPlainText(myText);

		// Markup the .sm file
		markup();
	}

	// Reset filename
	htmlFilename = "toHtml.html";
}

//****************************************************//
// Control+S Shortcut handler, saves content of
// text editor into a file of choice
//****************************************************//
void Ui_MainWindow::CTRL_S()
{
	// Specify filename and location
	QFileDialog *fd = new QFileDialog();
	fd->setAcceptMode(QFileDialog::AcceptSave);
	fd->setFileMode(QFileDialog::AnyFile);

	if(hasSaved)
	{
		filename = savedFilename;
		QString copy = filename;
		htmlFilename = copy.remove(".sm");
		htmlFilename = copy.append(".html");

		saveSmFile();
		markup();

		// Reset Filenames 
		htmlFilename = "toHtml.html";
		filename = "temp.sm";
	}
	
	else
	{
		if(fd->exec())
		{
			filename = fd->selectedFiles().front();

			// Append .sm if not already defined
			if(!filename.endsWith(".sm")) filename.append(".sm");
		
			// Create html filename
			QString copy = filename;
			htmlFilename = copy.remove(".sm");
			htmlFilename = copy.append(".html");
			savedFilename = filename;
			qDebug() << savedFilename << endl;
	
			// Save to file
			saveSmFile();

			// Markup and save to .html
			markup();
		}

		// Reset Filenames 
		htmlFilename = "toHtml.html";
		filename = "temp.sm";
		hasSaved = true;
	}
	
}

//****************************************************//
// Save text editor content to a file .html or .sm
//****************************************************//
void Ui_MainWindow::saveSmFile()
{	
    QFile outfile;	
	outfile.setFileName(filename);
    outfile.open(QFile::WriteOnly | QIODevice::Text);
    QTextStream out(&outfile);

	out << this->textEdit->toPlainText(); // << endl;
	out.flush();
	outfile.close();
}


//****************************************************//
// Save markedup array to .html file
//****************************************************//
void Ui_MainWindow::saveHtmlFile()
{
	QFile outfile;
	outfile.setFileName(htmlFilename);	
    outfile.open(QFile::WriteOnly | QIODevice::Truncate);
    QTextStream out(&outfile);

    // Prepend File:
	out << "<html>" << endl;
    out << "<body>" << endl;

    // Write the marked up HTML text to file
	for(int i = 0; i < arraySize; i++)
	{
		if(array[i] != "")
			out << array[i] << endl;
	}

	// Append File:
	out << "</body>" << endl;
    out << "</html>";
}

//****************************************************//
// Read in file content, return content as QString 
//****************************************************//
void Ui_MainWindow::readSmFile(QString &myText)
{
	// Read in file content
	QFile infile(filename);

	if(!infile.open(QFile::ReadOnly | QFile::Text))
	{
		qDebug() << "Could not open file";
		return;
	}

	// Output to QString the file content
	QTextStream in(&infile);
	myText = in.readAll();
	infile.close();

	return;
}

//******************************************************//
// Generic read file content, return content as QString 
// Used for testing 
//*******************************************************//
void Ui_MainWindow::readFile(QString &myText, QString fName)
{
	// Read in file content
	QFile infile(fName);

	if(!infile.open(QFile::ReadOnly | QFile::Text))
	{
		qDebug() << "Could not open file";
		return;
	}

	QTextStream in(&infile);
	myText = in.readAll();
	infile.close();

	return;
}

//**************************************************//
// Parse the text editor lines, markup to HMTL
//**************************************************//
void Ui_MainWindow::parse()
{
	bool header = false;
	bool smallHeader = false;

 	for(int i = 0; i < arraySize; i++)
	{
		QString str1 = list.at(i);
		QRegExp rx("[ ]");
		QStringList list1 = list.at(i).split(rx, QString::SkipEmptyParts);
		for(int j = 0; j < list1.size(); j++)
		{
			QString str = list1.at(j);
			QString dbl = list1.at(j);
			if(j == 0)
			{
				if(header);
				else if(smallHeader);
				else
				{
					if(str.startsWith("*") && !str.startsWith("**"))
					{
						str.prepend("<i>");
						str.prepend("<p>");
						str.remove("*");
					}
					else if(str.startsWith("**"))
					{
						str.prepend("<b>");
						str.prepend("<p>");
						str.remove("**");
					}
					else
						str.prepend("<p>");
				}
				
			}
			if(str.startsWith("**") && str.endsWith("**"))
    		{
    			str.append("</b>");
    			str.prepend("<b>");
    			str.remove("**");
    		}
    		else if(str.startsWith("**"))
    		{
    			str.prepend("<b>");
    			str.remove("**");
    		}
    		else if(str.endsWith("**"))
    		{
    			str.append("</b>");
    			str.remove("**");
    		}
    		if(str.startsWith("*") && str.endsWith("*"))
    		{
    			str.append("</i>");
    			str.prepend("<i>");
    			str.remove("*");
    		}
    		else if(str.startsWith("*") && !str.startsWith("**"))
    		{
    			str.prepend("<i>");
    			str.remove("*");
    		}
    		else if(str.endsWith("*") && !str.endsWith("**"))
    		{
    			str.append("</i>");
    			str.remove("*");
			}
			if(j == (list1.size()-1))
			{
				str.append("</p>");
			}
			if(str.startsWith("<p>="))
			{
				QString s1 = list.at(i);
				QString s2 = list.at(i-1);
				if(s1.size() >= s2.size())
					header = true;
			}
			if(str.startsWith("<p>-"))
			{
				QString s1 = list.at(i);
				QString s2 = list.at(i-1);
				if(s1.size() >= s2.size())
					smallHeader = true;
			}
    		str1.replace(dbl, str);
    	}

    	if(header)
    	{
    		QString s = list.at(i-1);
    		s.prepend("<h1>");
    		s.append("</h1>");
    		s.remove("<p>");
    		s.remove("</p>");
       		header = false;
       		array[i-1] = s; 
    	}
    	else if(smallHeader)
    	{
    		QString s = list.at(i-1);
    		s.prepend("<h2>");
    		s.append("</h2>");
    		s.remove("<p>");
    		s.remove("</p>");
       		smallHeader = false;
       		array[i-1] = s; 
    	}
    	else
    	{
    		array[i] = str1;
    	}
	}
}