#ifndef BASE_H
#define BASE_H

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QWidget>
#include <QStringListModel>
#include <QMouseEvent>
#include <vector>

struct player
{
	QPoint paddleLoc;
	int width;
	int height;
	int score;
};

class Base
{

public:
    virtual void setPaddleLocation(int x, int y, int index) = 0;
    virtual void setPaddleDimensions(int width, int height) = 0;
	virtual void setScore(int index, int score) = 0;
 	virtual QRect getPaddle(int index) = 0;
    virtual int getPaddleY(int index) = 0;
    virtual int getScore(int index) = 0;

    virtual void updateBallLoc(QPoint p) = 0;
    virtual QPoint getBallLoc() = 0;

};

#endif