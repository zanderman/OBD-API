#ifndef PLAYER_H
#define PLAYER_H

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QWidget>
#include <QDebug>
#include <vector>

#include "base.h"

class Player : public Base, public std::vector<player>
{

public:
    Player()
    {
        //qDebug() << "Player Constructor" << endl;
        player p1;
        p1.score = 0;
        this->push_back(p1);

        player p2;
        p2.score = 0;
        this->push_back(p2);
    }

    void setPaddleLocation(int x, int y, int index)
    {
        QPoint p(x,y);
        (*this)[index].paddleLoc = p;
    }

    void setPaddleDimensions(int width, int height)
    {
        (*this)[0].width = width;
        (*this)[0].height = height;
        (*this)[1].width = width;
        (*this)[1].height = height;
    }

    QRect getPaddle(int index)
    {
        QPoint loc = (*this)[index].paddleLoc;
        int w = (*this)[index].width;
        int h = (*this)[index].height;
        return QRect(loc.x(),loc.y(),w,h);
    }

    int getPaddleY(int index)
    {
        QPoint loc = (*this)[index].paddleLoc;
        return loc.y();
    }

    void updateBallLoc(QPoint p)
    {}

    QPoint getBallLoc()
    {}

    int getScore(int index)
    {
        return (*this)[index].score;
    }

    void setScore(int index, int score)
    {
        (*this)[index].score = score;
    }

};

#endif