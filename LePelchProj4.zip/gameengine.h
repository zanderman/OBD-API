#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QWidget>
#include <QStringListModel>
#include <QMouseEvent>
#include <vector>
#include <stdlib.h>
#include <random>

#include "ball.h"
#include "player.h"
#include "base.h"

#define PI 3.14159265358979323846


class GameEngine : public QObject//: public QWidget
{
	Q_OBJECT

//*****************************//
// Configuration Parameters
//*****************************//

// Paddle step size
const static int paddleStepSize = 25;

// Velocity magnitude
static constexpr double Vmag = 6.3;

// Minimum orientation (radians)
static constexpr double orientationMin = 0.0;

// Maximum orientation (radians)
static constexpr double orientationMax = (2*PI);


public:
    GameEngine(QObject *parent = 0);

public slots:
	void playerOneUp();
	void playerOneDown();
	void playerTwoUp();
	void playerTwoDown();
    void setModel(Base *m);
    void setBallModel(Base *m);
    void update();
    void quit();
    void getWindowSize(int width, int height);

signals:

protected:

private:
	bool playerTwoPoint();
	bool playerOnePoint();
	bool bounceBackLeft();
	bool bounceBackRight();
	bool bounceBackTop();
	bool bounceBackBottom();
	void ballPhysics();

	Base *base;
	Base *ball;
	QPoint ballLoc;

	enum states {upRight, upLeft, downRight,
	 			downLeft, restart, start} state;
	enum p {p1, p2};

	int playerOneY, playerTwoY;
	int threeSecCounter;
	int p1Score, p2Score;
	int winWidth, winHeight;
	int maxLeft, maxRight, left, right;
	int paddleWidth, paddleHeight;
	double ballVx, ballVy;

	std::mt19937 gen;

};

#endif