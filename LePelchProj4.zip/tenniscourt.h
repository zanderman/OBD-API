#ifndef TENNISCOURT_H
#define TENNISCOURT_H

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QWidget>
#include <QMouseEvent>

#include "ball.h"
#include "player.h"
#include "base.h"


class TennisCourt : public QWidget
{
    Q_OBJECT

public:
    TennisCourt(QWidget *parent = 0);

public slots:
	void playerOneUp();
    void playerOneDown();
    void playerTwoUp();
    void playerTwoDown();
    void setModel(Base *m);
    void setBallModel(Base *m);
    void timerUpdate();
    void quit();

signals:
	void setWindowSize(int width, int height);

protected:
	void resizeImage(QImage *image, const QSize &newSize);
	void paintEvent(QPaintEvent *event);
	void resizeEvent(QResizeEvent *event);
	void clearImage();
    
private:
	Base *player;
	Base *ball;
	QImage image;

	int playerOneY, playerTwoY;

};

#endif