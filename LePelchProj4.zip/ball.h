//*******************************************************************/
// ECE 3574, Project 2, Alexander LePelch
//
// File name: ball.h
//
// Description: Model class for "Ball" responsible for getting
//              and setting certain parameters
//*******************************************************************/

#ifndef BALL_H
#define BALL_H

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QWidget>
#include <QDebug>
#include <vector>

#include "base.h"

class Ball : public Base, public std::vector<player>
{

public:
    Ball()
    {
        //qDebug() << "Ball Constructor" << endl;
        player p;
        p.paddleLoc.setX(600);
        p.paddleLoc.setY(350);
        p.width = 5;
        p.height = 5;
        this->push_back(p);
    }

    void setPaddleLocation(int x, int y, int index)
    {
    
    }

    void setPaddleDimensions(int width, int height)
    {

    }

    QRect getPaddle(int index)
    {
        QPoint loc = (*this)[index].paddleLoc;
        int w = (*this)[index].width;
        int h = (*this)[index].height;
        return QRect(loc.x(),loc.y(),w,h);
    }

    int getPaddleY(int index)
    {
        return 2;
    }

    int getScore(int index)
    {
        return  0;
    }

    void setScore(int index, int score)
    {
    }

    void updateBallLoc(QPoint p)
    {
        (*this)[0].paddleLoc = p;
    }

    QPoint getBallLoc()
    {
        return (*this)[0].paddleLoc;
    }
};

#endif