#include <QTest>
#include <QApplication>
#include <QPixmap>
#include <QString>
#include <QtGui>
#include <QDebug>
#include <QFont>
#include <QTimer>
#include <iostream>

#include "mainwindow.h"

class MyTest: public QObject
{
public:
  	Q_OBJECT
  	
private slots:

  	void integrationTest();
};

void MyTest::integrationTest()
{
  MainWindow window;
  window.show();

  // Player one move down
  QTest::keyClick(window.tennisCourt, Qt::Key_A, Qt::NoModifier, 50);
  QPixmap pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-001.png");
  QTest::qWait(250);
  
  // Player one move down
  QTest::keyClick(window.tennisCourt, Qt::Key_A, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-002.png");
  QTest::qWait(250);
  
  // Player two move up
  QTest::keyClick(window.tennisCourt, Qt::Key_L, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-003.png");
  QTest::qWait(250);
  
  // Player two move up
  QTest::keyClick(window.tennisCourt, Qt::Key_L, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-004.png");
  QTest::qWait(250);

  // Player one move up
  QTest::keyClick(window.tennisCourt, Qt::Key_S, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-005.png");
  QTest::qWait(250);

  // Player two move down
  QTest::keyClick(window.tennisCourt, Qt::Key_K, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-006.png");
  QTest::qWait(250);

  // Quit Game
  QTest::keyClick(window.tennisCourt, Qt::Key_Q, Qt::NoModifier, 50);
  pixmap = QPixmap::grabWidget(window.tennisCourt);
  pixmap.save("test-007.png");
  QTest::qWait(250);
}

QTEST_MAIN(MyTest)
#include "mytest.moc"
