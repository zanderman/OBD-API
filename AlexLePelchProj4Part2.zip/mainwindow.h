#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QList>
#include <QtGui>
#include <QMainWindow>
#include <QDockWidget>
#include <QGridLayout>
#include <QGroupBox>
#include <QTextEdit>
#include <QThread>

#include "tenniscourt.h"
#include "gameengine.h"
#include "base.h"
#include "ball.h"

class Player;
class TennisCourt;
class GameEngine;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    QThread gameEngineThread;

public:
    MainWindow();
    ~MainWindow();
    TennisCourt* tennisCourt;
    GameEngine *gameEngine;

private slots:

private:
    void createConnections();
    void playerOneAct();
    void playerTwoAct();
    void setupQuitAct();   
    void setupTimerAct(); 
    void setupUserSignals();
    

    Player *players;
    Ball *ball;

    QGroupBox *gridGroupBox;
    QAction *playerOneUpAct;
    QAction *playerOneDownAct;
    QAction *playerTwoUpAct;
    QAction *playerTwoDownAct;
    QAction *quitAct;
    QTimer *timer;
};

#endif
