#include <QtGui>
#include <QFont>
#include <math.h>

#include "tenniscourt.h"

TennisCourt::TennisCourt(QWidget *parent)
    : QWidget(parent)
{
	//qDebug() << "TennisCourt Constructor" << endl;
}

void TennisCourt::resizeImage(QImage *image, const QSize &newSize)
{
    //qDebug() << "resizeImage()" << endl;

    if (image->size() == newSize)
        return;

    QImage newImage(QSize(2000, 1000),
        QImage::Format_RGB32);

    newImage.fill(qRgb(0, 0, 0));
    QPainter painter(&newImage);
    painter.drawImage(QPoint(0,0), *image);

    *image = newImage;
}

void TennisCourt::paintEvent(QPaintEvent *event)
{
    //qDebug() << "paintEvent" << endl;

    QPainter painter(this);
    QRect dirtyRect = event->rect();
    painter.drawImage(dirtyRect, image, dirtyRect);

    // Draw Center Line
    painter.setPen(QPen(Qt::white, 3, Qt::DotLine));
    painter.drawLine(QPoint((width()/2),0), QPoint((width()/2),height()));
    
    // Draw Paddles
    painter.setPen(QPen(Qt::white, 3, Qt::SolidLine));
    painter.drawRect(player->getPaddle(0));
    painter.drawRect(player->getPaddle(1));

    // Draw Ball
    painter.setBrush(Qt::white);
    painter.drawEllipse(ball->getPaddle(0));

    // Draw Score
    QPoint p1((width()/2 - 17),15);
    QPoint p2((width()/2 + 10),15);
    QString s1 = QString::number(player->getScore(0));
    QString s2 = QString::number(player->getScore(1));
    painter.drawText(p1, s1);
    painter.drawText(p2, s2);
}

void TennisCourt::resizeEvent(QResizeEvent *event)
{
    //qDebug() << "resizeEvent()" << endl;

    if (width() > image.width() || height() > image.height()) {
        int newWidth = qMax(width() + 128, image.width());
        int newHeight = qMax(height() + 128, image.height());
        resizeImage(&image, QSize(newWidth, newHeight));
        update();
    }
    QWidget::resizeEvent(event);

    emit setWindowSize(width(), height());
}

void TennisCourt::setModel(Base *m) 
{
    player = m;
}

void TennisCourt::setBallModel(Base *m) 
{
    ball = m;
}

void TennisCourt::clearImage()
{
    image.fill(qRgb(0, 0, 0));
    update();
}

void TennisCourt::playerOneUp()
{
    clearImage();
}   

void TennisCourt::playerOneDown()
{
    clearImage();
}

void TennisCourt::playerTwoUp()
{
    clearImage();
}   

void TennisCourt::playerTwoDown()
{
    clearImage();
}

void TennisCourt::timerUpdate()
{
    clearImage();
}

void TennisCourt::quit()
{
}