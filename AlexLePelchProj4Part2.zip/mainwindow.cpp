#include <QtGui>
#include <QDockWidget>
#include <QGridLayout>

#include "mainwindow.h"

MainWindow::MainWindow()
{
    resize(783, 600);

    players = new Player;
    ball = new Ball;
    tennisCourt = new TennisCourt;
    gameEngine = new GameEngine;
    gameEngine->moveToThread(&gameEngineThread);

    gameEngine->setModel(players);
    tennisCourt->setModel(players);
    gameEngine->setBallModel(ball);
    tennisCourt->setBallModel(ball);

    setCentralWidget(tennisCourt);

    createConnections();
    setWindowTitle(tr("Tennis"));
    gameEngineThread.start();
}

MainWindow::~MainWindow()
{
    //qDebug() << "Main Window Destructor" << endl;
    gameEngineThread.quit();
    gameEngineThread.wait();
}

void MainWindow::createConnections()
{   
    // Setup Player 1 Actions
    playerOneAct();

    // Setup Player 2 Actions
    playerTwoAct();

    // Setup Quit Action
    setupQuitAct();  

    // Setup update Timer Actionss
    setupTimerAct();  

    // Setup user defined signals/slots
    setupUserSignals();
}

void MainWindow::playerOneAct()
{
    // Player One Up Acion 
    playerOneUpAct = new QAction(tr("&playerOneUp"), this);
    playerOneUpAct->setShortcut(tr("s"));
    connect(playerOneUpAct, SIGNAL(triggered()),
        tennisCourt, SLOT(playerOneUp()));
    tennisCourt->addAction(playerOneUpAct);
    connect(playerOneUpAct, SIGNAL(triggered()),
        gameEngine, SLOT(playerOneUp()));
    //gameEngine->addAction(playerOneUpAct);

    // Player One Down Acion 
    playerOneDownAct = new QAction(tr("&playerOneDown"), this);
    playerOneDownAct->setShortcut(tr("a"));
    connect(playerOneDownAct, SIGNAL(triggered()), 
            tennisCourt, SLOT(playerOneDown()));
    tennisCourt->addAction(playerOneDownAct);
    connect(playerOneDownAct, SIGNAL(triggered()), 
            gameEngine, SLOT(playerOneDown()));
    //gameEngine->addAction(playerOneDownAct);
}

void MainWindow::playerTwoAct()
{
    // Player Two Up Acion 
    playerTwoUpAct = new QAction(tr("&playerTwoUp"), this);
    playerTwoUpAct->setShortcut(tr("l"));
    connect(playerTwoUpAct, SIGNAL(triggered()), 
            tennisCourt, SLOT(playerTwoUp()));
    tennisCourt->addAction(playerTwoUpAct);
    connect(playerTwoUpAct, SIGNAL(triggered()),
        gameEngine, SLOT(playerTwoUp()));
    //gameEngine->addAction(playerTwoUpAct);

    // Player Two Down Acion 
    playerTwoDownAct = new QAction(tr("&playerTwoDown"), this);
    playerTwoDownAct->setShortcut(tr("k"));
    connect(playerTwoDownAct, SIGNAL(triggered()), 
            tennisCourt, SLOT(playerTwoDown()));
    tennisCourt->addAction(playerTwoDownAct);
    connect(playerTwoDownAct, SIGNAL(triggered()), 
            gameEngine, SLOT(playerTwoDown()));
    //gameEngine->addAction(playerTwoDownAct);
}

void MainWindow::setupQuitAct()
{
    // Quit the game
    quitAct = new QAction(tr("&quit"), this);
    quitAct->setShortcut(tr("q"));
    connect(quitAct, SIGNAL(triggered()),
            gameEngine, SLOT(quit()));
    //gameEngine->addAction(quitAct);
    connect(quitAct, SIGNAL(triggered()),
            tennisCourt, SLOT(quit()));
    tennisCourt->addAction(quitAct);
    connect(quitAct, SIGNAL(triggered()), this, SLOT(close()));
}

void MainWindow::setupTimerAct()
{
    // Setup timer signal
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), gameEngine, SLOT(update()));
    connect(timer, SIGNAL(timeout()), tennisCourt, SLOT(timerUpdate()));
    timer->start(16);
}

void MainWindow::setupUserSignals()
{
    connect(tennisCourt, SIGNAL(setWindowSize(int, int)),
            gameEngine, SLOT(getWindowSize(int, int)));

}


