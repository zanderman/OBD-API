#include <QtGui>
#include <QFont>
#include <math.h>

#include "gameengine.h"

GameEngine::GameEngine(QObject *parent)
    : QObject(parent)
{
	//qDebug() << "GameEngine Constructor" << endl;
    std::random_device rd;
    gen.seed(rd());
    state = start;
}

void GameEngine::playerOneUp()
{
    playerOneY = base->getPaddleY(p1);
    playerOneY = playerOneY - paddleStepSize;
    if(playerOneY < (0+5)) playerOneY = (0+5);
    base->setPaddleLocation(maxLeft, playerOneY, p1);
}   

void GameEngine::playerOneDown()
{
    playerOneY = base->getPaddleY(p1);
    playerOneY = playerOneY + paddleStepSize;
    if(playerOneY > (winHeight-paddleHeight-5)) 
        playerOneY = (winHeight-paddleHeight-5);
    base->setPaddleLocation(maxLeft, playerOneY, p1);
}

void GameEngine::playerTwoUp()
{    
    playerTwoY = base->getPaddleY(p2);
    playerTwoY = playerTwoY - paddleStepSize;
    if(playerTwoY < (0+5)) playerTwoY = (0+5);
    base->setPaddleLocation(right, playerTwoY, p2);    
}   

void GameEngine::playerTwoDown()
{
    playerTwoY = base->getPaddleY(p2);
    playerTwoY = playerTwoY + paddleStepSize;
    if(playerTwoY > (winHeight-paddleHeight-5)) 
        playerTwoY = (winHeight-paddleHeight-5);
    base->setPaddleLocation(right, playerTwoY, p2);    
}

void GameEngine::update()
{
    // Get current ball location
    ballLoc = ball->getBallLoc();

    switch(state)
    {
        case start:
        {
            // randomly select ball orientation, position, velocity
            QPoint p((winWidth/2), (rand() % winHeight));
            ball->updateBallLoc(p);

            std::uniform_real_distribution<double> x((PI),(orientationMax)); 

            double orientation = x(gen);
            //qDebug() << "Orientation: " << orientation << endl;

            ballVx = Vmag*cos(orientation);
            ballVy = Vmag*sin(orientation);
            if(ballVx < 0) ballVx = ballVx*(-1);
            if(ballVy < 0) ballVy = ballVy*(-1);
            if(ballVy < 1 && ballVy > 0) ballVy = 1;
            if(ballVx < 1 && ballVx > 0) ballVx = 1;


            if(orientation >= 0 && orientation < (PI/2)) state = upRight;
            else if(orientation >= (PI/2) && orientation < PI) state = upLeft;
            else if(orientation >= PI && orientation < (3*PI/2)) state = downLeft;
            else state = downRight;
            break;
        }

        case upRight:
        {
            // Bounce off paddle?
            if(bounceBackLeft()) break;

            // Player 1 point?
            if(playerOnePoint()) break;

            // Bounce off top?
            if(bounceBackTop()) break;

            // Update ball location
            ballPhysics();
            break;
        }

        case upLeft:
        {
            // Bounce off paddle?
            if(bounceBackRight()) break;

            // Player 2 Point?
            if(playerTwoPoint()) break;

            // Bouce off top?
            if(bounceBackTop()) break;

            // Update ball location
            ballPhysics();
            break;
        }

        case downLeft:
        {
            // Bounce off paddle?
            if(bounceBackRight()) break;

            // Player 2 Point?
            if(playerTwoPoint()) break;

            // Bounce off bottom?
            if(bounceBackBottom()) break;

            // Update ball location
            ballPhysics();
            break;
        }

        case downRight:
        {
            // Bounce off paddle?
            if(bounceBackLeft()) break;

            // Player 1 point? 
            if(playerOnePoint()) break;

            // Bounce off bottom?
            if(bounceBackBottom()) break;
        
            // Update ball location
            ballPhysics();
            break;
        }

        case restart:
        {
            threeSecCounter++;
            if(threeSecCounter >= 180)
            {
                threeSecCounter = 0;
                state = start;
            }
            break;
        }
    }
}

void GameEngine::ballPhysics()
{
    if(state == upRight || state == upLeft)
    {
        ballLoc.setY(ballLoc.y() - ballVy);
        if(state == upRight) 
            ballLoc.setX(ballLoc.x() + ballVx);
        else 
            ballLoc.setX(ballLoc.x() - ballVx);
    }
    else
    {
        ballLoc.setY(ballLoc.y() + ballVy);
        if(state == downRight)
            ballLoc.setX(ballLoc.x() + ballVx);
        else
            ballLoc.setX(ballLoc.x() - ballVx);
    }
    // Update ball location
    ball->updateBallLoc(ballLoc);
}

bool GameEngine::bounceBackTop()
{
    if(ballLoc.y() <= (winHeight-winHeight))
    {
        if(state == upLeft) state = downLeft;
        else if(state == upRight) state = downRight;
        return true;
    }
    return false;
}

bool GameEngine::bounceBackBottom()
{
    if(ballLoc.y() >= winHeight)
    {
        if(state == downRight) state = upRight;
        else if(state == downLeft) state = upLeft;
        return true;
    }
    return false;
}

bool GameEngine::playerTwoPoint()
{
    if(ballLoc.x() <= maxLeft)
    {
        int x = base->getScore(p2);
        base->setScore(p2, x+1);
        state = restart;
        return true;
    }
    return false;
}

bool GameEngine::playerOnePoint()
{
    if(ballLoc.x() <= maxRight && ballLoc.x() >= (maxRight-5))
    {
        int x = base->getScore(p1);
        base->setScore(p1, x+1);
        state = restart;
        return true;
    }
    return false;
}

bool GameEngine::bounceBackLeft()
{
    if(ballLoc.x() <= right && ballLoc.x() >= (right-5))
    {
        int paddleY = base->getPaddleY(p2);
        if(ballLoc.y() >= paddleY && ballLoc.y() <= (paddleY+paddleHeight))
        {
            if(state == downRight) state = downLeft;
            else if(state == upRight) state = upLeft;
            return true;
        }
    }
    return false;
}

bool GameEngine::bounceBackRight()
{
    if(ballLoc.x() <= left && ballLoc.x() >= (left-5))
    {
        int paddleY = base->getPaddleY(p1);
        if(ballLoc.y() >= paddleY && ballLoc.y() <= (paddleY+paddleHeight))
        {
            if(state == downLeft) state = downRight;
            else if(state == upLeft) state = upRight;
            return true;   
        }
    }
    return false;
}

void GameEngine::getWindowSize(int width, int height)
{
    //qDebug() << "Get Window Size" << endl;
    paddleWidth = width/64;
    paddleHeight = height/8;
    winWidth = width;
    winHeight = height;
    maxLeft = (0+5);
    maxRight = (width-5);
    left = maxLeft + paddleWidth;
    right = maxRight - paddleWidth;

    base->setPaddleDimensions(paddleWidth, paddleHeight);
    base->setPaddleLocation(maxLeft, (height/2 - (paddleHeight/2)), p1);
    base->setPaddleLocation(right, (height/2 - (paddleHeight/2)), p2);
}

void GameEngine::setModel(Base *m) 
{
    base = m;
}

void GameEngine::setBallModel(Base *m) 
{
    ball = m;
}

void GameEngine::quit()
{

}