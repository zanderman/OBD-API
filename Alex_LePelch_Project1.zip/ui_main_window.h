// ******************************************************************/
// ECE 3574, Project 1, Alexander LePelch
//
// File name: ui_main_window.h
//
// Description: This include file outlines the public and private
//              members of this class. This class defines the 
//              main window of a GUI consisting of a text editor
//              on the left with a splitter separating the QWebViewer
//              on the right.
//              
//              Slots:
//              markup(): Performs marking up of content in text
//              editor. Is triggered whenever there is a change
//              in the text editor content
//              
//              viewHtml(): Reads the content of .html file and 
//              renders it in the QWebView window.
//
//              CTRL_S(): This slot performs a save of the content
//              available in the text editor. It creates a .sm
//              and .html file wherever the user defines.
// 
//              CTRL_O(): This slot loads in the content of  a user 
//              selected file into the text editor. It is then
//              rendered on the right screen, the QWebViewer.
// ******************************************************************/

#ifndef _UI_MAINWINDOW_H
#define _UI_MAINWINDOW_H

#include <QTextStream>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QSplitter>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>
#include <QtWebKit/QWebView>
#include <QFileDialog>
#include <QFile>
#include <QDialog>

QT_BEGIN_NAMESPACE

class Ui_MainWindow : public QObject
{
public:
    QTextEdit *textEdit;
    QString myTextOpen;

    Ui_MainWindow();    // Constructor
    ~Ui_MainWindow();   // Destructor

    // Set up the User Interface
    void setupUi(QMainWindow *MainWindow);

    // Convert block of text into array of Strings by line
    void myTextToArray(QString &myText);

    // Parse the text array
    void parse();
    
    // Save text editor content to .sm file 
    void saveSmFile();

    // Save marked up content to .html file
    void saveHtmlFile();

    // Read in a .sm file to text editor 
    void readSmFile(QString &myText);

    // Generic read file used for testing
    void readFile(QString &myText, QString fName);

    Q_OBJECT

    public slots:

    // Read in .sm file, parse the text, and markup to HTML format
    void markup();

    // View the HTML file in WebViewer window
    void viewHTML();

    void CTRL_O(); // Open and read in a file to text editor
    void CTRL_S(); // Save text editor and webview content to
                   // .sm and .html files respectively

private:
    QString filename;       // .SM Filename
    QString htmlFilename;   // .Html Filename
    QString *array;         // Array that holds html text
    QStringList list;       // List of lines in text editor
    int arraySize;          // Size of array 'a'

    QWebView *webView;
    QMenuBar *menubar;
    QAction *action;
    QStatusBar *statusbar;
    QWidget *centralwidget;
    QSplitter *splitter;
};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // _UI_MAINWINDOW_H
