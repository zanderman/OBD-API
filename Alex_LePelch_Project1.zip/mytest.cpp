//*******************************************************************/
// ECE 3574, Project 1, Alexander LePelch
//
// File name: mytest.cpp
//
// Description: This program tests output of QT Markup application.
//*******************************************************************/

#include <QTest>
#include "ui_main_window.h"
#include <QApplication>
#include <QPushButton>
#include <QTextEdit>
#include <QString>
#include <QWebView>
#include <QtGui>
#include <iostream>

#include "ui_main_window.h"

class MyTest: public QObject
{
public:
  	Q_OBJECT

  	
private slots:

  	void testMarkupSingleLines();
  	void testMarkupManyLines();
  
};

void MyTest::testMarkupSingleLines()
{
	QMainWindow *mainWindow = new QMainWindow();
  	Ui_MainWindow mainWin;
  	mainWin.setupUi(mainWindow);

  	int num = 3;

  	// List of QTextEditor Inputs 
  	QString seq[num];
  	seq[0] = "This is *italic font.*";
  	seq[1] = "This is **bold** font.";
  	seq[2] = "*This is **bold** within italics.*";

  	// List of expected results in temp 'toHtml.html' file
  	QString expRes1[num];
  	expRes1[0] = "<html>\n<body>\n<p>This is <i>italic font.</i></p>\n</body>\n</html>";
  	expRes1[1] = "<html>\n<body>\n<p>This is <b>bold</b> font.</p>\n</body>\n</html>";
  	expRes1[2] = "<html>\n<body>\n<p><i>This is <b>bold</b> within italics.</i></p>\n</body>\n</html>";
  
  	QString myText[num];

  	for(int i = 0; i < num; i++)
  	{
  		QTest::keyClicks(mainWin.textEdit, seq[i], Qt::NoModifier, -1);

      QCOMPARE(mainWin.myTextOpen, seq[i]);
  		//mainWin.readFile(myText[i], "detail.sm");
  		//QCOMPARE(myText[i], seq[i]);

  		mainWin.readFile(myText[i], "toHtml.html");
  		QCOMPARE(myText[i], expRes1[i]);

  		mainWin.textEdit->clear();
  	}
} 

void MyTest::testMarkupManyLines()
{
	// Instantiate class
	QMainWindow *mainWindow = new QMainWindow();
  	Ui_MainWindow mainWin;
  	mainWin.setupUi(mainWindow);

  	// Define number of test inputs
  	int num = 2;

  	// Test input arrays
  	QString mul[num], mul1[num];
  	mul[0] =  "Big Header";
  	mul1[0] = "============";

  	mul[1] =  "Small Header";
  	mul1[1] = "----------------";

  	// Expected output array
  	QString expRes[num];
  	expRes[0] = "<html>\n<body>\n<h1>Big Header</h1>\n</body>\n</html>";
  	expRes[1] = "<html>\n<body>\n<h2>Small Header</h2>\n</body>\n</html>";

  	QString myText[num];

  	for(int i = 0; i < num; i++)
  	{
  		QTest::keyClicks(mainWin.textEdit, mul[i], Qt::NoModifier, -1);
  		QTest::keyPress(mainWin.textEdit, Qt::Key_Return, Qt::NoModifier, -1);
  		QTest::keyClicks(mainWin.textEdit, mul1[i], Qt::NoModifier, -1);

  		mainWin.readFile(myText[i], "toHtml.html");
  		QCOMPARE(myText[i], expRes[i]);

  		mainWin.textEdit->clear();
  	}
  	
}

QTEST_MAIN(MyTest)
#include "mytest.moc"
