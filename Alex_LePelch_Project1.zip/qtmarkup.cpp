//*******************************************************************/
// ECE 3574, Project 1, Alexander LePelch
//
// File name: qtmarkup.cpp
//
// Description: This file creates the application QT Markup
//*******************************************************************/

#include <QApplication>
#include <QPushButton>
#include <QTextEdit>
#include <QString>
#include <QWebView>
#include <QtGui>
#include <iostream>

#include "ui_main_window.h"

int main(int argc, char *argv[])
{
  // Create application
  QApplication app(argc, argv);
  app.setApplicationName("Qt Markup");

  // Initialize main window
  QMainWindow *mainWindow = new QMainWindow();
  Ui_MainWindow mainWin;

  // Display the window
  mainWin.setupUi(mainWindow);
  mainWindow->show(); 

  return app.exec();
}
